/opt/etl/prd/etl/APP/ADW/B_MBIRDIE_DATA_TRANSFER/bin> cat b_mbirdie_data_transfer0010.pl 
######################################################
#   $Header: /CVSROOT/smartone/Code/ETL/Template/b_JobName0010.pl,v 1.2 2005/11/16 08:35:06 MichaelNg Exp $
#   Purpose:
#
#
######################################################


use Date::Manip;
use DBI;
use Spreadsheet::WriteExcel;
use Math::BigFloat;

my $ETLVAR = $ENV{"AUTO_ETLVAR"};
require $ETLVAR;

my $MASTER_TABLE = ""; #Please input the final target ADW table name here

my $TDSVR,$TDUSR,$TDPWD,$TDDB,$TDTABLE,$ENV,$OUTPUT_FILE_PATH;
my $FILE_PREFIX, $FILE_DATE;
my $REPORT_DATE, $ABNORMAL_FOUND, $ABNORMAL_RATE;

my $dbh, $datastmt, $ret;


##################################################################################################################################
##################################################################################################################################
##################################################################################################################################



sub runSQLPLUS{
  my $SQLCMD_FILE="${etlvar::AUTO_GEN_TEMP_PATH}${etlvar::ETLJOBNAME}_sqlcmd.sql";
  open SQLCMD, ">" . $SQLCMD_FILE || die "Cannot open file" ;
  print SQLCMD<<ENDOFINPUT;
        ${etlvar::LOGON_TD}
        ${etlvar::SET_MAXERR}
        ${etlvar::SET_ERRLVL_1}
        ${etlvar::SET_ERRLVL_2}
        set define off;

--Please type your SQL statement here
TRUNCATE TABLE ${etlvar::TMPDB}.B_MBIRDIE_DATA_TRANSFER_TMP001;

INSERT INTO ${etlvar::TMPDB}.B_MBIRDIE_DATA_TRANSFER_TMP001
(
        RECORD_ID
        , USER_ID
        , SUBR_NUM
        , CUST_NUM
        , TYPE
        , DATA_SIZE
        , DATA_VOL
        , TRANSFER_FROM_USER_ID
        , TRANSFER_FROM_SUBR_NUM
        , TRANSFER_FROM_CUST_NUM
        , TRANSFER_TO_USER_ID
        , TRANSFER_TO_SUBR_NUM
        , TRANSFER_TO_CUST_NUM
        , TRX_DATE
        , TRX_TIME
        , CREATE_TS
        , REFRESH_TS
)
select 
RECORD_ID
, USER_ID as USER_ID
, SUBR_NUM as SUBR_NUM
, CUST_NUM as CUST_NUM
, TYPE
, - DATA_SIZE
, - DATA_SIZE / 1024 as DATA_VOL
, ' ' as TRANSFER_FROM_USER_ID
, ' ' as TRANSFER_FROM_SUBR_NUM
, ' ' as TRANSFER_TO_USER_ID
, TRANSFER_TO_USER_ID
, TRANSFER_TO_SUBR_NUM
, TRANSFER_TO_CUST_NUM
, TRX_DATE, TRX_TIME
,TO_TIMESTAMP('${etlvar::LOADTIME}', 'YYYY-MM-DD HH24:MI:SS') AS CREATE_TS
,TO_TIMESTAMP('${etlvar::LOADTIME}', 'YYYY-MM-DD HH24:MI:SS') AS REFRESH_TS
from ${etlvar::TMPDB}.D_MBIRDIE_DATA_TRANSFER
where type in ('transfer','other_transfer')
union
select 
RECORD_ID
, TRANSFER_TO_USER_ID as USER_ID
, TRANSFER_TO_SUBR_NUM as SUBR_NUM
, TRANSFER_TO_CUST_NUM as CUST_NUM
, TYPE
, DATA_SIZE
, DATA_SIZE / 1024 as DATA_VOL
, USER_ID as TRANSFER_FROM_USER_ID
, SUBR_NUM as TRANSFER_FROM_SUBR_NUM
, CUST_NUM as TRANSFER_TO_USER_ID
, ' ' as TRANSFER_TO_USER_ID
, ' ' as TRANSFER_TO_SUBR_NUM
, ' ' as TRANSFER_TO_CUST_NUM
, TRX_DATE, TRX_TIME
,TO_TIMESTAMP('${etlvar::LOADTIME}', 'YYYY-MM-DD HH24:MI:SS') AS CREATE_TS
,TO_TIMESTAMP('${etlvar::LOADTIME}', 'YYYY-MM-DD HH24:MI:SS') AS REFRESH_TS
from ${etlvar::TMPDB}.D_MBIRDIE_DATA_TRANSFER
where type in ('transfer','other_transfer')
union
select 
RECORD_ID
, USER_ID
, SUBR_NUM
, CUST_NUM
, TYPE
, DATA_SIZE
, DATA_SIZE / 1024 as DATA_VOL
, TRANSFER_FROM_USER_ID
, TRANSFER_FROM_SUBR_NUM
, TRANSFER_FROM_CUST_NUM
, TRANSFER_TO_USER_ID
, TRANSFER_TO_SUBR_NUM
, TRANSFER_TO_CUST_NUM
, TRX_DATE, TRX_TIME
,TO_TIMESTAMP('${etlvar::LOADTIME}', 'YYYY-MM-DD HH24:MI:SS') AS CREATE_TS
,TO_TIMESTAMP('${etlvar::LOADTIME}', 'YYYY-MM-DD HH24:MI:SS') AS REFRESH_TS
from ${etlvar::TMPDB}.D_MBIRDIE_DATA_TRANSFER
where type not in ('transfer','other_transfer')
;


EXIT;

ENDOFINPUT
  close(SQLCMD);
  print("sqlplus /\@${etlvar::TDDSN} \@$SQLCMD_FILE");
  my $ret = system("sqlplus /\@${etlvar::TDDSN} \@$SQLCMD_FILE");
  if ($ret != 0)
  {
    return (1);
  }
  return 0;

}


##################################################################################################################################
##################################################################################################################################
##################################################################################################################################



sub initParam{

    print("\n\n\n#####################################\n");
    print("#  Init Parameters\n");
    print("#####################################\n\n");

    my $err = "";

    # ------------------------------------------------------------------#
    #  Please define the parameters for this job below.                 #
    # ------------------------------------------------------------------#

    #my $rundate = DateCalc("${etlvar::TXDATE}", "- 1 days", \$err);
    #my $From_rundate = DateCalc("${etlvar::TXDATE}", "- 0 days", \$err);
    #my $To_rundate = DateCalc("${etlvar::TXDATE}", "- 0 days", \$err);
    #$REPORT_DATE = &UnixDate($rundate, "%Y-%m-%d");
    #$FROM_REPORT_DATE = &UnixDate($From_rundate, "%Y-%m-%d");
    #$TO_REPORT_DATE = &UnixDate($To_rundate, "%Y-%m-%d");
    #$FILE_DATE = &UnixDate($rundate, "%Y%m%d");


    my $rundate = DateCalc("${etlvar::TXDATE}", "- 0 days", \$err);
    my $From_rundate =&UnixDate(DateCalc("${etlvar::TXDATE}", "- 1 days", \$err), "%Y%m");
    my $To_rundate = DateCalc("${etlvar::TXDATE}", "- 1 days", \$err);
    $REPORT_DATE = &UnixDate($rundate, "%Y-%m-%d");
    $FROM_REPORT_DATE = &UnixDate("${From_rundate}01", "%Y-%m-%d");
    $SUBJECT_REPORT_DATE = &UnixDate($From_rundate, "%Y%m");
    $TO_REPORT_DATE = &UnixDate($To_rundate, "%Y-%m-%d");
    $FILE_DATE = &UnixDate($rundate, "%Y%m");



    if ($ENV eq "DEV"){

        ##  DEVELOPMENT  ##
        $TDUSR = "${etlvar::TDUSR}";
        $TDPWD = "${etlvar::TDPWD}";
        $TDDSN = $ENV{"AUTO_DSN"};

        $OUTPUT_FILE_PATH = "";
        $FILE_PREFIX = "";

    }
    else
    {
        ##  PRODUCTION  ##
        $TDUSR = "${etlvar::TDUSR}";
        $TDPWD = "${etlvar::TDPWD}";
        $TDDSN = $ENV{"AUTO_DSN"};

        $OUTPUT_FILE_PATH = "";
        $FILE_PREFIX = "";

    }

    $ABNORMAL_FOUND=0;
    $ABNORMAL_RATE=0.8;
}


##################################################################################################################################
##################################################################################################################################
##################################################################################################################################




#We need to have variable input for the program to start
if ($#ARGV < 0){
    print("Syntax : perl <Script Name> <System Name>_<Job Name>_<TXDATE>.dir>\n");
    print("Example: perl b_cust_info0010.pl adw_b_cust_info_20051010.dir\n");
    exit(1);
}


#Call the function we want to run
open(STDERR, ">&STDOUT");

my $pre = etlvar::preProcess($ARGV[0]);
my $rc = etlvar::getTXDate($MASTER_TABLE);

# disable print buffer
$| = 1;

#init param
initParam();

$ret = runSQLPLUS();









if($ret == 0)
{

}



my $post = etlvar::postProcess();

exit($ret);














