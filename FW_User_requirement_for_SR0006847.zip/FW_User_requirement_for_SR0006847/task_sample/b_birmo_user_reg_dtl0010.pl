/opt/etl/prd/etl/APP/ADW/B_BIRMO_USER_REG_DTL/bin> cat b_birmo_user_reg_dtl0010.plb_birmo_user_reg_dtl0010.plb_birmo_user_reg_dtl0010.plb_birmo_user_reg_dtl0010.pll;
cat: b_birmo_user_reg_dtl0010.plb_birmo_user_reg_dtl0010.plb_birmo_user_reg_dtl0010.plb_birmo_user_reg_dtl0010.pll: No such file or directory
/opt/etl/prd/etl/APP/ADW/B_BIRMO_USER_REG_DTL/bin> cat b_birmo_user_reg_dtl0010.pl
######################################################
#   $Header:
#   Purpose:
#
#
######################################################



my $ETLVAR = $ENV{"AUTO_ETLVAR"};require $ETLVAR;

my $MASTER_TABLE = ""; #Please input the final target ADW table name here


sub runSQLPLUS{
    my $rc = open(SQLPLUS, "| sqlplus /\@${etlvar::TDDSN}");
    unless ($rc){
        print "Cound not invoke SQLPLUS commAND\n";
        return -1;
    }

    print SQLPLUS<<ENDOFINPUT;
      ${etlvar::LOGON_TD}
      ${etlvar::SET_MAXERR}
      ${etlvar::SET_ERRLVL_1}
      ${etlvar::SET_ERRLVL_2}
EXECUTE ${etlvar::UTLDB}.ETL_UTILITY.truncate_tbl2(P_schema_tbl_name=>'${etlvar::TMPDB}.B_BIRMO_USER_REG_DTL_000A');
EXECUTE ${etlvar::UTLDB}.ETL_UTILITY.truncate_tbl2(P_schema_tbl_name=>'${etlvar::TMPDB}.B_BIRMO_USER_REG_DTL_000B');
EXECUTE ${etlvar::UTLDB}.ETL_UTILITY.truncate_tbl2(P_schema_tbl_name=>'${etlvar::TMPDB}.B_BIRMO_USER_REG_DTL_000');
EXECUTE ${etlvar::UTLDB}.ETL_UTILITY.truncate_tbl2(P_schema_tbl_name=>'${etlvar::TMPDB}.B_BIRMO_USER_REG_DTL_001');
EXECUTE ${etlvar::UTLDB}.ETL_UTILITY.truncate_tbl2(P_schema_tbl_name=>'${etlvar::TMPDB}.B_BIRMO_USER_REG_DTL_002');



INSERT /*+ APPEND */ INTO  ${etlvar::TMPDB}.B_BIRMO_USER_REG_DTL_000A
( USER_ID
  ,SUBR_NUM
  ,CUST_NUM
  ,REG_TYPE
  ,STATUS
  ,BILL_CYCLE
  ,REFERRER_USER_ID
  ,REFERRER_SUBR_NUM
  ,REFERRER_CUST_NUM
  ,CREATE_DATE
  ,CREATE_TIME
  ,SERVICE_PENDING_START_DATE
  ,SERVICE_PENDING_START_TIME
  ,CHL
  ,REFERRER_CD
  ,ECR
  ,ORDER_NUM
  ,RATE_PLAN_CD
  ,DAY_OF_BIRTH
  ,CONTACT_NUM
  ,OPER_CONTACT_NUM
  ,OPER_PORTIN
  ,TITLE
  ,EMAIL_ADDR
  ,DELIVERY_PREFERENCE
  ,FIRST_PAYMENT_TOOL_REG
  ,AUTOPAY_INDICATOR
  ,PORT_IN_OPER_CUST_SELECTED
  ,BOLT_ON_BILL_CODE)
SELECT USER_ID
  ,SUBR_NUM
  ,CUST_NUM
  ,REG_TYPE
  ,STATUS
  ,BILL_CYCLE
  ,REFERRER_USER_ID
  ,REFERRER_SUBR_NUM
  ,REFERRER_CUST_NUM
  ,CREATE_DATE
  ,CREATE_TIME
  ,SERVICE_PENDING_START_DATE
  ,SERVICE_PENDING_START_TIME
  ,CHL
  ,REFERRER_CD
  ,ECR
  ,ORDER_NUM
  ,RATE_PLAN_CD
  ,DAY_OF_BIRTH
  ,CONTACT_NUM
  ,OPER_CONTACT_NUM
  ,OPER_PORTIN
  ,TITLE
  ,EMAIL_ADDR
  ,DELIVERY_PREFERENCE
,FIRST_PAYMENT_TOOL_REG
    ,AUTOPAY_INDICATOR
          ,PORT_IN_OPER_CUST_SELECTED
           ,BOLT_ON_BILL_CODE 
FROM (SELECT a.USER_ID
  ,a.SUBR_NUM
  ,a.CUST_NUM
  ,a.REG_TYPE
  ,a.STATUS
  ,a.BILL_CYCLE
  ,a.REFERRER_USER_ID
  ,a.REFERRER_SUBR_NUM
  ,a.REFERRER_CUST_NUM
  ,a.CREATE_DATE
  ,a.CREATE_TIME
  ,a.SERVICE_PENDING_START_DATE
  ,a.SERVICE_PENDING_START_TIME
  ,a.CHL
  ,a.REFERRER_CD
  ,a.ECR
  ,a.ORDER_NUM
  ,a.RATE_PLAN_CD
  ,a.DAY_OF_BIRTH
  ,a.CONTACT_NUM
  ,COALESCE((CASE WHEN f.Port_Type = 'R' THEN (COALESCE(g.Netw_Oper_Cd, ' ')) ELSE f.Rno END),(COALESCE(g.Netw_Oper_Cd, ' '))) AS OPER_CONTACT_NUM
  ,a.OPER_PORTIN
  ,a.TITLE
  ,a.EMAIL_ADDR
  ,a.DELIVERY_PREFERENCE
  ,a.FIRST_PAYMENT_TOOL_REG
  ,a.AUTOPAY_INDICATOR
    ,a.PORT_IN_OPER_CUST_SELECTED
          ,a.BOLT_ON_BILL_CODE
  ,ROW_NUMBER() OVER(PARTITION BY a.USER_ID,a.SUBR_NUM,a.CUST_NUM,a.REG_TYPE,a.STATUS,a.BILL_CYCLE,a.REFERRER_USER_ID
                                          ,a.REFERRER_SUBR_NUM,a.REFERRER_CUST_NUM,a.CREATE_DATE,a.CREATE_TIME,a.SERVICE_PENDING_START_DATE,a.SERVICE_PENDING_START_TIME,a.CHL
                                          ,a.REFERRER_CD,a.ECR,a.ORDER_NUM,a.RATE_PLAN_CD,a.DAY_OF_BIRTH,a.CONTACT_NUM,a.TITLE,a.EMAIL_ADDR
                                          ORDER BY PORTING_DATE DESC, PORTING_TIME DESC) SWV_Qualify
FROM ${etlvar::TMPDB}.D_BIRMO_USER_REG_DTL a
--FROM ${etlvar::ADWDB}.BIRMO_USER_REG_DTL a
LEFT OUTER JOIN ${etlvar::ADWDB}.SUBR_PORTING_EVENT f
ON f.Subr_Num = (CASE WHEN SUBSTR(a.CONTACT_NUM,1,3) = '852' THEN SUBSTR(a.CONTACT_NUM,4) ELSE a.CONTACT_NUM END)
AND TO_DATE(TO_CHAR(f.PORTING_DATE,'yyyymmdd')||TO_CHAR(LPAD(f.PORTING_TIME,6,0)),'yyyymmddhh24miss') < TO_DATE(TO_CHAR(a.CREATE_DATE,'yyyymmdd')||TO_CHAR(LPAD(a.CREATE_TIME,6,0)),'yyyymmddhh24miss')
LEFT OUTER JOIN ${etlvar::ADWDB}.NUM_BLK g
ON (CASE WHEN SUBSTR(a.CONTACT_NUM,1,3) = '852' THEN SUBSTR(a.CONTACT_NUM,4) ELSE a.CONTACT_NUM END) >= g.Blk_Start
AND (CASE WHEN SUBSTR(a.CONTACT_NUM,1,3) = '852' THEN SUBSTR(a.CONTACT_NUM,4) ELSE a.CONTACT_NUM END) <= g.Blk_End) T
WHERE SWV_Qualify = 1;

INSERT /*+ APPEND */ INTO  ${etlvar::TMPDB}.B_BIRMO_USER_REG_DTL_000B
( USER_ID
  ,SUBR_NUM
  ,CUST_NUM
  ,REG_TYPE
  ,STATUS
  ,BILL_CYCLE
  ,REFERRER_USER_ID
  ,REFERRER_SUBR_NUM
  ,REFERRER_CUST_NUM
  ,CREATE_DATE
  ,CREATE_TIME
  ,SERVICE_PENDING_START_DATE
  ,SERVICE_PENDING_START_TIME
  ,CHL
  ,REFERRER_CD
  ,ECR
  ,ORDER_NUM
  ,RATE_PLAN_CD
  ,DAY_OF_BIRTH
  ,CONTACT_NUM
  ,OPER_CONTACT_NUM
  ,OPER_PORTIN
  ,TITLE
  ,EMAIL_ADDR
  ,DELIVERY_PREFERENCE
  ,FIRST_PAYMENT_TOOL_REG
  ,AUTOPAY_INDICATOR
    ,PORT_IN_OPER_CUST_SELECTED
          ,BOLT_ON_BILL_CODE)
SELECT USER_ID
  ,SUBR_NUM
  ,CUST_NUM
  ,REG_TYPE
  ,STATUS
  ,BILL_CYCLE
  ,REFERRER_USER_ID
  ,REFERRER_SUBR_NUM
  ,REFERRER_CUST_NUM
  ,CREATE_DATE
  ,CREATE_TIME
  ,SERVICE_PENDING_START_DATE
  ,SERVICE_PENDING_START_TIME
  ,CHL
  ,REFERRER_CD
  ,ECR
  ,ORDER_NUM
  ,RATE_PLAN_CD
  ,DAY_OF_BIRTH
  ,CONTACT_NUM
  ,OPER_CONTACT_NUM
  ,OPER_PORTIN
  ,TITLE
  ,EMAIL_ADDR
  ,DELIVERY_PREFERENCE
  ,FIRST_PAYMENT_TOOL_REG
  ,AUTOPAY_INDICATOR
    ,PORT_IN_OPER_CUST_SELECTED
          ,BOLT_ON_BILL_CODE
FROM (SELECT a.USER_ID
  ,a.SUBR_NUM
  ,a.CUST_NUM
  ,a.REG_TYPE
  ,a.STATUS
  ,a.BILL_CYCLE
  ,a.REFERRER_USER_ID
  ,a.REFERRER_SUBR_NUM
  ,a.REFERRER_CUST_NUM
  ,a.CREATE_DATE
  ,a.CREATE_TIME
  ,a.SERVICE_PENDING_START_DATE
  ,a.SERVICE_PENDING_START_TIME
  ,a.CHL
  ,a.REFERRER_CD
  ,a.ECR
  ,a.ORDER_NUM
  ,a.RATE_PLAN_CD
  ,a.DAY_OF_BIRTH
  ,a.CONTACT_NUM
  ,a.OPER_CONTACT_NUM
  ,CASE WHEN a.REG_TYPE NOT IN ('portin_prepaid','portin_postpaid')
        THEN ' '
        ELSE COALESCE((CASE WHEN f.Port_Type = 'R' THEN (COALESCE(g.Netw_Oper_Cd, ' ')) ELSE f.rno END),(COALESCE(g.Netw_Oper_Cd, ' ')))  END AS OPER_PORTIN
  ,a.TITLE
  ,a.EMAIL_ADDR
  ,a.DELIVERY_PREFERENCE
  ,a.FIRST_PAYMENT_TOOL_REG
  ,a.AUTOPAY_INDICATOR
    ,a.PORT_IN_OPER_CUST_SELECTED
          ,a.BOLT_ON_BILL_CODE
  ,ROW_NUMBER() OVER(PARTITION BY a.USER_ID,a.SUBR_NUM,a.CUST_NUM,a.REG_TYPE,a.STATUS,a.BILL_CYCLE,a.REFERRER_USER_ID
                                          ,a.REFERRER_SUBR_NUM,a.REFERRER_CUST_NUM,a.CREATE_DATE,a.CREATE_TIME,a.SERVICE_PENDING_START_DATE,a.SERVICE_PENDING_START_TIME,a.CHL
                                          ,a.REFERRER_CD,a.ECR,a.ORDER_NUM,a.RATE_PLAN_CD,a.DAY_OF_BIRTH,a.CONTACT_NUM,a.TITLE,a.EMAIL_ADDR
                                          ORDER BY PORTING_DATE DESC, PORTING_TIME DESC) SWV_Qualify
FROM ${etlvar::TMPDB}.B_BIRMO_USER_REG_DTL_000A a
LEFT OUTER JOIN ${etlvar::ADWDB}.SUBR_PORTING_EVENT f
ON f.Subr_Num = (CASE WHEN SUBSTR(a.SUBR_NUM,1,3) = '852' THEN SUBSTR(a.SUBR_NUM,4) ELSE a.SUBR_NUM END)
AND TO_DATE(TO_CHAR(f.PORTING_DATE,'yyyymmdd')||TO_CHAR(LPAD(f.PORTING_TIME,6,0)),'yyyymmddhh24miss') < TO_DATE(TO_CHAR(a.CREATE_DATE,'yyyymmdd')||TO_CHAR(LPAD(a.CREATE_TIME,6,0)),'yyyymmddhh24miss')
LEFT OUTER JOIN ${etlvar::ADWDB}.NUM_BLK g
ON (CASE WHEN SUBSTR(a.SUBR_NUM,1,3) = '852' THEN SUBSTR(a.SUBR_NUM,4) ELSE a.SUBR_NUM END) >= g.Blk_Start
AND (CASE WHEN SUBSTR(a.SUBR_NUM,1,3) = '852' THEN SUBSTR(a.SUBR_NUM,4) ELSE a.SUBR_NUM END) <= g.Blk_End) T
WHERE SWV_Qualify = 1;


INSERT /*+ APPEND */ INTO  ${etlvar::TMPDB}.B_BIRMO_USER_REG_DTL_000
( USER_ID
  ,SUBR_NUM
  ,CUST_NUM
  ,REG_TYPE
  ,STATUS
  ,BILL_CYCLE
  ,REFERRER_USER_ID
  ,REFERRER_SUBR_NUM
  ,REFERRER_CUST_NUM
  ,CREATE_DATE
  ,CREATE_TIME
  ,SERVICE_PENDING_START_DATE
  ,SERVICE_PENDING_START_TIME
  ,CHL
  ,REFERRER_CD
  ,ECR
  ,ORDER_NUM
  ,RATE_PLAN_CD
  ,DAY_OF_BIRTH
  ,CONTACT_NUM
  ,OPER_CONTACT_NUM
  ,OPER_PORTIN
  ,TITLE
  ,EMAIL_ADDR
  ,DELIVERY_PREFERENCE
  ,FIRST_PAYMENT_TOOL_REG
  ,AUTOPAY_INDICATOR
   ,PORT_IN_OPER_CUST_SELECTED
  ,BOLT_ON_BILL_CODE   )
SELECT USER_ID
  ,SUBR_NUM
  ,CUST_NUM
  ,REG_TYPE
  ,STATUS
  ,BILL_CYCLE
  ,REFERRER_USER_ID
  ,REFERRER_SUBR_NUM
  ,REFERRER_CUST_NUM
  ,CREATE_DATE
  ,CREATE_TIME
  ,SERVICE_PENDING_START_DATE
  ,SERVICE_PENDING_START_TIME
  ,CHL
  ,REFERRER_CD
  ,ECR
  ,ORDER_NUM
  ,RATE_PLAN_CD
  ,DAY_OF_BIRTH
  ,CONTACT_NUM
  ,COALESCE(c.NETW_OPER,' ')
  ,COALESCE(c2.NETW_OPER,' ')
  ,TITLE
  ,EMAIL_ADDR
  ,DELIVERY_PREFERENCE
  ,FIRST_PAYMENT_TOOL_REG
  ,AUTOPAY_INDICATOR
    ,PORT_IN_OPER_CUST_SELECTED
  ,BOLT_ON_BILL_CODE
FROM ${etlvar::TMPDB}.B_BIRMO_USER_REG_DTL_000B a
LEFT OUTER JOIN ${etlvar::ADWDB}.NETW_OPER_REF c
ON a.OPER_CONTACT_NUM = c.NETW_OPER_CD
LEFT OUTER JOIN ${etlvar::ADWDB}.NETW_OPER_REF c2
ON a.OPER_PORTIN = c2.NETW_OPER_CD;

INSERT /*+ APPEND */ INTO  ${etlvar::TMPDB}.B_BIRMO_USER_REG_DTL_001
(
     USER_ID
     ,SUBR_NUM
     ,CUST_NUM
     ,REG_TYPE
     ,STATUS
     ,BILL_CYCLE
     ,REFERRER_USER_ID
     ,REFERRER_SUBR_NUM
     ,REFERRER_CUST_NUM
     ,CREATE_DATE
     ,CREATE_TIME
     ,SERVICE_PENDING_START_DATE
     ,SERVICE_PENDING_START_TIME
     ,CHL
     ,REFERRER_CD
     ,ECR
     ,ORDER_NUM
         ,RATE_PLAN_CD
     ,DAY_OF_BIRTH
     ,CONTACT_NUM
     ,OPER_CONTACT_NUM
     ,OPER_PORTIN
     ,TITLE
     ,ONLINE_STORE_FLG
     ,D_OPER_CONTACT_NUM
     ,D_RATE_PLAN_CD_CNUM
     ,D_RATE_PLAN_GRP_CNUM
     ,D_FREE_DATA_ENTITLE_CNUM
     ,D_REVENUE_FLG_CNUM
     ,D_SUBR_SW_ON_DATE_CNUM
     ,D_SUBR_SW_OFF_DATE_CNUM
     ,D_TENURE_CNUM
     ,D_OPER_PORTIN
     ,D_RATE_PLAN_CD_PTIN
     ,D_RATE_PLAN_GRP_PTIN
     ,D_FREE_DATA_ENTITLE_PTIN
     ,D_REVENUE_FLG_PTIN
     ,D_SUBR_SW_ON_DATE_PTIN
     ,D_SUBR_SW_OFF_DATE_PTIN
     ,D_TENURE_PTIN
         ,EMAIL_ADDR
     ,DELIVERY_PREFERENCE
     ,FIRST_PAYMENT_TOOL_REG
  ,AUTOPAY_INDICATOR
    ,PORT_IN_OPER_CUST_SELECTED
  ,BOLT_ON_BILL_CODE
)
SELECT DISTINCT a.USER_ID
     ,a.SUBR_NUM
     ,a.CUST_NUM
     ,a.REG_TYPE
     ,a.STATUS
     ,a.BILL_CYCLE
     ,a.REFERRER_USER_ID
     ,a.REFERRER_SUBR_NUM
     ,a.REFERRER_CUST_NUM
     ,a.CREATE_DATE
     ,a.CREATE_TIME
     ,a.SERVICE_PENDING_START_DATE
     ,a.SERVICE_PENDING_START_TIME
     ,a.CHL
     ,a.REFERRER_CD
     ,a.ECR
     ,a.ORDER_NUM
         ,a.RATE_PLAN_CD
     ,a.DAY_OF_BIRTH
     ,a.CONTACT_NUM
     ,a.OPER_CONTACT_NUM
     ,a.OPER_PORTIN
     ,a.TITLE
     ,CASE WHEN b.ORDER_REFERENCE IS NOT NULL THEN 'Y' ELSE 'N' END
     ,CASE WHEN a.OPER_CONTACT_NUM <> ' ' THEN
               CASE WHEN a.OPER_CONTACT_NUM LIKE 'SmarTone%' THEN
                                                  CASE WHEN c2.netw = 16 THEN 'Birdie'
                                                       WHEN c2.netw = 17 THEN 'Global Call (SMC side)'
                                                           WHEN c2.netw = 15 THEN
                                                                        CASE WHEN c2.rate_plan_grp in (select rate_plan_grp from ${etlvar::ADWDB}.PRF_MVNOS_RPGRP)
                                                                                 THEN 'HKBN (SMC Side)'
                                                                                 ELSE 'Roaming wholesale project' END
                                                           WHEN c2.rate_plan_grp = 'BIRDIES' THEN 'Travel Birdie'
                                                           ELSE a.OPER_CONTACT_NUM END
                ELSE a.OPER_CONTACT_NUM END
                        ELSE a.OPER_CONTACT_NUM END     AS D_OPER_CONTACT_NUM
     ,CASE WHEN a.OPER_CONTACT_NUM LIKE 'SmarTone%' THEN coalesce(c2.rate_plan_cd,c4.BILL_SERV_CD,' ') ELSE ' ' END AS D_RATE_PLAN_CD_CNUM
     ,CASE WHEN a.OPER_CONTACT_NUM LIKE 'SmarTone%' THEN coalesce(c2.rate_plan_grp,c4.rate_plan_grp,' ') ELSE ' ' END AS D_RATE_PLAN_GRP_CNUM
     ,CASE WHEN a.OPER_CONTACT_NUM LIKE 'SmarTone%' THEN coalesce(e.FREE_DATA_ENTITLE,' ') ELSE ' ' END AS D_FREE_DATA_ENTITLE_CNUM
     ,CASE WHEN a.OPER_CONTACT_NUM LIKE 'SmarTone%' THEN
                                              CASE WHEN c2.netw is not null
                                                       then CASE WHEN (SUBSTR(a.CONTACT_NUM,1,1) in ('2','3') OR coalesce(c2.netw,9) IN (7,8,11,12,13)) AND COALESCE(f.Msisdn, ' ') <> ' '
                                                                          THEN 'N'
                                                                          WHEN c2.Rate_Plan_Grp IN ('Add-on Numbers', 'Non Revenue Mobile Plan', 'Non Revenue BB Line', 'DHL Special Project')
                                                                          THEN 'N'
                                                                          WHEN g.Cust_Type_Cd IN (select Cust_Type_Cd from ${etlvar::ADWDB}.BIRMO_EXC_CUST_TYPE) and c2.netw = 16
                                                                          THEN 'N'
                                                                          WHEN c2.Rate_Plan_Grp IN (select Rate_Plan_Grp from ${etlvar::ADWDB}.BIRMO_EXC_RPGRP) and c2.netw = 16
                                                                          THEN 'N'
                                                                          WHEN g.Cust_Type_Cd IN (select Cust_Type_Cd from ${etlvar::ADWDB}.PRF_EXCLUDE_CUST_TYPE) and c2.netw <> 16
                                                                          THEN 'N'
                                                                          WHEN c2.Rate_Plan_Grp IN (select Rate_Plan_Grp from ${etlvar::ADWDB}.PRF_EXCLUDE_RPGRP) and c2.netw <> 16
                                                                          THEN 'N'
                                                                          WHEN c.imsi IN (select imsi from ${etlvar::ADWDB}.BIRMO_EXLC_IMSI) and c2.netw = 16
                                                                          THEN 'N'
                                                                          ELSE 'Y' END
                                                       WHEN c4.BILL_SERV_CD is not null
                                                       then CASE WHEN COALESCE(f.Msisdn, ' ') <> ' '
                                                                          THEN 'N'
                                                                          ELSE 'Y' END
                                                       else ' ' END
                    ELSE ' ' END AS D_REVENUE_FLG_CNUM
     ,CASE WHEN a.OPER_CONTACT_NUM LIKE 'SmarTone%' THEN
                                              CASE WHEN c2.netw is not null
                                                       then c.SUBR_SW_ON_DATE
                               WHEN c4.BILL_SERV_CD is not null
                                                       then c3.SUBR_SW_ON_DATE
                                                       ELSE TO_DATE('${etlvar::MINDATE}','YYYY-MM-DD') END
                    ELSE TO_DATE('${etlvar::MINDATE}','YYYY-MM-DD') END AS D_SUBR_SW_ON_DATE_CNUM
     ,CASE WHEN a.OPER_CONTACT_NUM LIKE 'SmarTone%' THEN
                                              CASE WHEN c2.netw is not null
                                                       then c.SUBR_SW_OFF_DATE
                               WHEN c4.BILL_SERV_CD is not null
                                                       then c3.SUBR_SW_OFF_DATE
                                                       ELSE TO_DATE('${etlvar::MINDATE}','YYYY-MM-DD') END
                    ELSE TO_DATE('${etlvar::MINDATE}','YYYY-MM-DD') END AS D_SUBR_SW_OFF_DATE_CNUM
     ,CASE WHEN a.OPER_CONTACT_NUM LIKE 'SmarTone%' THEN
                                              CASE WHEN c2.netw is not null
                                                       then a.CREATE_DATE-c.SUBR_SW_ON_DATE
                               WHEN c4.BILL_SERV_CD is not null
                                                       then a.CREATE_DATE-c3.SUBR_SW_ON_DATE
                                                       ELSE 0 END
                    ELSE 0 END  AS D_TENURE_CNUM
     ,CASE WHEN a.REG_TYPE NOT IN ('portin_prepaid','portin_postpaid')
        THEN ' '
        ELSE CASE WHEN a.OPER_PORTIN <> ' ' AND a.OPER_PORTIN NOT LIKE 'SmarTone%'
            THEN a.OPER_PORTIN
                        ELSE CASE  WHEN d2.netw = 17 THEN 'Global Call (SMC side)'
                                  WHEN d2.netw = 15 THEN
                                          CASE WHEN d2.rate_plan_grp in (select rate_plan_grp from ${etlvar::ADWDB}.PRF_MVNOS_RPGRP)
                                                   THEN 'HKBN (SMC Side)'
                                                   ELSE 'Roaming wholesale project' END                           
                                          WHEN d2.rate_plan_grp = 'BIRDIES' THEN 'Travel Birdie'
                                          ELSE a.OPER_PORTIN END END END AS D_OPER_PTIN
     ,CASE WHEN a.REG_TYPE NOT IN ('portin_prepaid','portin_postpaid')
        THEN ' '
        ELSE CASE WHEN a.OPER_PORTIN LIKE 'SmarTone%' OR (a.OPER_PORTIN = ' ' AND (d2.netw = 15 OR d2.rate_plan_grp = 'BIRDIES'))
                                        THEN coalesce(d2.rate_plan_cd,d4.BILL_SERV_CD,' ')
                    ELSE ' ' END END AS D_RATE_PLAN_CD_PTIN
     ,CASE WHEN a.REG_TYPE NOT IN ('portin_prepaid','portin_postpaid')
        THEN ' '
        ELSE CASE WHEN a.OPER_PORTIN LIKE 'SmarTone%' OR (a.OPER_PORTIN = ' ' AND (d2.netw = 15  OR d2.rate_plan_grp = 'BIRDIES'))
                                        THEN coalesce(d2.rate_plan_grp,d4.rate_plan_grp,' ')
                    ELSE ' ' END END AS D_RATE_PLAN_GRP_PTIN
     ,CASE WHEN a.REG_TYPE NOT IN ('portin_prepaid','portin_postpaid')
        THEN ' '
        ELSE CASE WHEN a.OPER_PORTIN LIKE 'SmarTone%' OR (a.OPER_PORTIN = ' ' AND (d2.netw = 15  OR d2.rate_plan_grp = 'BIRDIES'))
                                        THEN  coalesce(e2.FREE_DATA_ENTITLE,' ')
                    ELSE ' ' END END AS D_FREE_DATA_ENTITLE_PTIN
     ,CASE WHEN a.REG_TYPE NOT IN ('portin_prepaid','portin_postpaid')
        THEN ' '
        ELSE CASE WHEN a.OPER_PORTIN LIKE 'SmarTone%' OR (a.OPER_PORTIN = ' ' AND (d2.netw = 15  OR d2.rate_plan_grp = 'BIRDIES')) THEN
                                              CASE WHEN d2.netw is not null
                                                       then CASE WHEN (SUBSTR(a.SUBR_NUM,1,1) in ('2','3') OR coalesce(c2.netw,9) IN (7,8,11,12,13)) AND COALESCE(f2.Msisdn, ' ') <> ' '
                                                                          THEN 'N'
                                                                          WHEN d2.Rate_Plan_Grp IN ('Add-on Numbers', 'Non Revenue Mobile Plan', 'Non Revenue BB Line', 'DHL Special Project')
                                                                          THEN 'N'
                                                                          WHEN g2.Cust_Type_Cd IN (select Cust_Type_Cd from ${etlvar::ADWDB}.BIRMO_EXC_CUST_TYPE) and d2.netw = 16
                                                                          THEN 'N'
                                                                          WHEN d2.Rate_Plan_Grp IN (select Rate_Plan_Grp from ${etlvar::ADWDB}.BIRMO_EXC_RPGRP) and d2.netw = 16
                                                                          THEN 'N'
                                                                          WHEN g2.Cust_Type_Cd IN (select Cust_Type_Cd from ${etlvar::ADWDB}.PRF_EXCLUDE_CUST_TYPE) and d2.netw <> 16
                                                                          THEN 'N'
                                                                          WHEN d2.Rate_Plan_Grp IN (select Rate_Plan_Grp from ${etlvar::ADWDB}.PRF_EXCLUDE_RPGRP) and d2.netw <> 16
                                                                          THEN 'N'
                                                                          WHEN d.imsi IN (select imsi from ${etlvar::ADWDB}.BIRMO_EXLC_IMSI) and d2.netw = 16
                                                                          THEN 'N'
                                                                          ELSE 'Y' END
                                                       WHEN d4.BILL_SERV_CD is not null
                                                       then CASE WHEN COALESCE(f2.Msisdn, ' ') <> ' '
                                                                          THEN 'N'
                                                                          ELSE 'Y' END
                                                       else ' ' END
                    ELSE ' ' END END AS D_REVENUE_FLG_PTIN
     ,CASE WHEN a.REG_TYPE NOT IN ('portin_prepaid','portin_postpaid')
        THEN TO_DATE('${etlvar::MINDATE}','YYYY-MM-DD')
        ELSE CASE WHEN a.OPER_PORTIN LIKE 'SmarTone%' OR (a.OPER_PORTIN = ' ' AND (d2.netw = 15  OR d2.rate_plan_grp = 'BIRDIES')) THEN
                                              CASE WHEN d2.netw is not null
                                                       then d.SUBR_SW_ON_DATE
                               WHEN d4.BILL_SERV_CD is not null
                                                       then d3.SUBR_SW_ON_DATE
                                                       ELSE TO_DATE('${etlvar::MINDATE}','YYYY-MM-DD') END
                    ELSE TO_DATE('${etlvar::MINDATE}','YYYY-MM-DD') END END AS D_SUBR_SW_ON_DATE_PTIN
     ,CASE WHEN a.REG_TYPE NOT IN ('portin_prepaid','portin_postpaid')
        THEN TO_DATE('${etlvar::MINDATE}','YYYY-MM-DD')
        ELSE CASE WHEN a.OPER_PORTIN LIKE 'SmarTone%' OR (a.OPER_PORTIN = ' ' AND (d2.netw = 15  OR d2.rate_plan_grp = 'BIRDIES')) THEN
                                              CASE WHEN d2.netw is not null
                                                       then d.SUBR_SW_OFF_DATE
                               WHEN d4.BILL_SERV_CD is not null
                                                       then d3.SUBR_SW_OFF_DATE
                                                       ELSE TO_DATE('${etlvar::MINDATE}','YYYY-MM-DD') END
                    ELSE TO_DATE('${etlvar::MINDATE}','YYYY-MM-DD') END END AS D_SUBR_SW_OFF_DATE_PTIN
     ,CASE WHEN a.REG_TYPE NOT IN ('portin_prepaid','portin_postpaid')
        THEN 0
        ELSE CASE WHEN a.OPER_PORTIN LIKE 'SmarTone%' OR (a.OPER_PORTIN = ' ' AND (d2.netw = 15  OR d2.rate_plan_grp = 'BIRDIES')) THEN
                                              CASE WHEN d2.netw is not null
                                                       then a.CREATE_DATE-d.SUBR_SW_ON_DATE
                               WHEN d4.BILL_SERV_CD is not null
                                                       then a.CREATE_DATE-d3.SUBR_SW_ON_DATE
                                                       ELSE 0 END
                    ELSE 0 END END AS D_TENURE_PTIN
        ,a.EMAIL_ADDR
    ,a.DELIVERY_PREFERENCE
    ,a.FIRST_PAYMENT_TOOL_REG
  ,a.AUTOPAY_INDICATOR
    ,a.PORT_IN_OPER_CUST_SELECTED
  ,a.BOLT_ON_BILL_CODE
FROM ${etlvar::TMPDB}.B_BIRMO_USER_REG_DTL_000 a
LEFT OUTER JOIN ${etlvar::TMPDB}.D_EC_ORDER_CASE b
ON a.ORDER_NUM = b.ORDER_REFERENCE
LEFT OUTER JOIN ${etlvar::ADWDB}.SUBR_INFO_HIST c
ON a.CONTACT_NUM = c.subr_num
AND c.subr_stat_cd = 'OK'
AND a.CREATE_DATE between c.start_date and c.end_date
LEFT OUTER JOIN ${etlvar::ADWDB}.CUST_INFO_HIST g
ON c.cust_num = g.cust_num
AND a.CREATE_DATE between g.start_date and g.end_date
LEFT OUTER JOIN ${etlvar::ADWDB}.RATE_PLAN_REF c2
ON c.rate_plan_Cd = c2.rate_plan_Cd
LEFT OUTER JOIN ${etlvar::ADWDB}.NSP_SUBR_INFO_HIST c3
ON a.CONTACT_NUM = c3.subr_num
AND c3.LC_State IN ('Active', 'LeeWay')
AND a.CREATE_DATE between c3.start_date and c3.end_date
LEFT OUTER JOIN ${etlvar::ADWDB}.NSP_RATE_PLAN_REF c4
ON c3.rate_plan_Cd = c4.BILL_SERV_CD
LEFT OUTER JOIN ${etlvar::ADWDB}.SUBR_DATA_ENTITLE_HIST e
ON c.cust_num = e.cust_num
AND a.CONTACT_NUM = e.subr_num
AND a.CREATE_DATE between e.start_date and e.end_date
LEFT OUTER JOIN ${etlvar::ADWDB}.PREPD_DEMO_CARD f
ON f.Sim = coalesce(c.Cust_Num,c3.Cust_Num,' ')
AND f.Msisdn = a.CONTACT_NUM
LEFT OUTER JOIN ${etlvar::ADWDB}.SUBR_INFO_HIST d
ON a.subr_num = d.subr_num
AND d.subr_stat_cd = 'OK'
AND a.CREATE_DATE between d.start_date and d.end_date
LEFT OUTER JOIN ${etlvar::ADWDB}.CUST_INFO_HIST g2
ON d.cust_num = g2.cust_num
AND a.CREATE_DATE between g2.start_date and g2.end_date
LEFT OUTER JOIN ${etlvar::ADWDB}.RATE_PLAN_REF d2
ON d.rate_plan_Cd = d2.rate_plan_Cd
LEFT OUTER JOIN ${etlvar::ADWDB}.NSP_SUBR_INFO_HIST d3
ON a.subr_num = d3.subr_num
AND d3.LC_State IN ('Active', 'LeeWay')
AND a.CREATE_DATE between d3.start_date and d3.end_date
LEFT OUTER JOIN ${etlvar::ADWDB}.NSP_RATE_PLAN_REF d4
ON d3.rate_plan_Cd = d4.BILL_SERV_CD
LEFT OUTER JOIN ${etlvar::ADWDB}.SUBR_DATA_ENTITLE_HIST e2
ON d.cust_num = e2.cust_num
AND a.subr_num = e2.subr_num
AND a.CREATE_DATE between e2.start_date and e2.end_date
LEFT OUTER JOIN ${etlvar::ADWDB}.PREPD_DEMO_CARD f2
ON f2.Sim = coalesce(d.Cust_Num,d3.Cust_Num,' ')
AND f2.Msisdn = a.subr_num;

-- handling active transcation.
-- case 1: active transcation without previous pending transcation.
INSERT INTO ${etlvar::TMPDB}.B_BIRMO_USER_REG_DTL_002
SELECT *
FROM ${etlvar::TMPDB}.B_BIRMO_USER_REG_DTL_001 a
where a.status = 'active'
AND NOT EXISTS (
        SELECT 'X'
        FROM ${etlvar::ADWDB}.BIRMO_USER_REG_DTL ex
        where a.USER_ID = ex.USER_ID
        and ex.status = 'pending')
-- if active transcation in production table , no need to insert
AND NOT EXISTS (
        SELECT 'X'
        FROM ${etlvar::ADWDB}.BIRMO_USER_REG_DTL ex
        where a.USER_ID = ex.USER_ID
        and ex.status = 'active');

-- case 1: active transcation with previous pending transcation.
INSERT /*+ APPEND */ INTO  ${etlvar::TMPDB}.B_BIRMO_USER_REG_DTL_002
(
     USER_ID
     ,SUBR_NUM
     ,CUST_NUM
     ,REG_TYPE
     ,STATUS
     ,BILL_CYCLE
     ,REFERRER_USER_ID
     ,REFERRER_SUBR_NUM
     ,REFERRER_CUST_NUM
     ,CREATE_DATE
     ,CREATE_TIME
     ,SERVICE_PENDING_START_DATE
     ,SERVICE_PENDING_START_TIME
     ,CHL
     ,REFERRER_CD
     ,ECR
     ,ORDER_NUM
         ,RATE_PLAN_CD
     ,DAY_OF_BIRTH
     ,CONTACT_NUM
     ,OPER_CONTACT_NUM
     ,OPER_PORTIN
     ,TITLE
     ,ONLINE_STORE_FLG
     ,D_OPER_CONTACT_NUM
     ,D_OPER_PORTIN
     ,D_RATE_PLAN_CD_PTIN
     ,D_RATE_PLAN_GRP_PTIN
     ,D_FREE_DATA_ENTITLE_PTIN
     ,D_REVENUE_FLG_PTIN
     ,D_SUBR_SW_ON_DATE_PTIN
     ,D_SUBR_SW_OFF_DATE_PTIN
     ,D_TENURE_PTIN
     ,D_RATE_PLAN_CD_CNUM
     ,D_RATE_PLAN_GRP_CNUM
     ,D_FREE_DATA_ENTITLE_CNUM
     ,D_REVENUE_FLG_CNUM
     ,D_SUBR_SW_ON_DATE_CNUM
     ,D_SUBR_SW_OFF_DATE_CNUM
     ,D_TENURE_CNUM
         ,EMAIL_ADDR
     ,DELIVERY_PREFERENCE
     ,FIRST_PAYMENT_TOOL_REG
  ,AUTOPAY_INDICATOR
    ,PORT_IN_OPER_CUST_SELECTED
  ,BOLT_ON_BILL_CODE
)
SELECT DISTINCT
     a.USER_ID
     ,a.SUBR_NUM
     ,a.CUST_NUM
     ,b.REG_TYPE
     ,a.STATUS
     ,b.BILL_CYCLE
     ,b.REFERRER_USER_ID
     ,b.REFERRER_SUBR_NUM
     ,b.REFERRER_CUST_NUM
     ,b.CREATE_DATE
     ,b.CREATE_TIME
     ,b.SERVICE_PENDING_START_DATE
     ,b.SERVICE_PENDING_START_TIME
     ,b.CHL
     ,b.REFERRER_CD
     ,b.ECR
     ,b.ORDER_NUM
         ,b.RATE_PLAN_CD
     ,b.DAY_OF_BIRTH
     ,b.CONTACT_NUM
     ,b.OPER_CONTACT_NUM
     ,b.OPER_PORTIN
     ,b.TITLE
     ,b.ONLINE_STORE_FLG
     ,b.D_OPER_CONTACT_NUM
     ,b.D_OPER_PORTIN
     ,b.D_RATE_PLAN_CD_PTIN
     ,b.D_RATE_PLAN_GRP_PTIN
     ,b.D_FREE_DATA_ENTITLE_PTIN
     ,b.D_REVENUE_FLG_PTIN
     ,b.D_SUBR_SW_ON_DATE_PTIN
     ,b.D_SUBR_SW_OFF_DATE_PTIN
     ,b.D_TENURE_PTIN
     ,b.D_RATE_PLAN_CD_CNUM
     ,b.D_RATE_PLAN_GRP_CNUM
     ,b.D_FREE_DATA_ENTITLE_CNUM
     ,b.D_REVENUE_FLG_CNUM
     ,b.D_SUBR_SW_ON_DATE_CNUM
     ,b.D_SUBR_SW_OFF_DATE_CNUM
     ,b.D_TENURE_CNUM
         ,b.EMAIL_ADDR
     ,b.DELIVERY_PREFERENCE
     ,b.FIRST_PAYMENT_TOOL_REG
     ,b.AUTOPAY_INDICATOR
    ,CASE WHEN a.PORT_IN_OPER_CUST_SELECTED <> '  ' AND b.PORT_IN_OPER_CUST_SELECTED = '  ' THEN 
a.PORT_IN_OPER_CUST_SELECTED ELSE b.PORT_IN_OPER_CUST_SELECTED END
    ,CASE WHEN a.BOLT_ON_BILL_CODE <> '  ' AND b.BOLT_ON_BILL_CODE = '  ' THEN 
a.BOLT_ON_BILL_CODE ELSE b.BOLT_ON_BILL_CODE END
FROM ${etlvar::TMPDB}.B_BIRMO_USER_REG_DTL_001 a
LEFT OUTER JOIN ${etlvar::ADWDB}.BIRMO_USER_REG_DTL b
ON a.User_id = b.user_id
where a.status = 'active'
and b.status = 'pending'
-- checking pending transcation in production table under same user id. if yes, the data columns refers to pending transcation.
AND EXISTS (
        SELECT 'X'
        FROM ${etlvar::ADWDB}.BIRMO_USER_REG_DTL ex
        where a.USER_ID = ex.USER_ID
        and ex.status = 'pending')
-- if active transcation in production table , no need to insert
AND NOT EXISTS (
        SELECT 'X'
        FROM ${etlvar::ADWDB}.BIRMO_USER_REG_DTL ex
        where a.USER_ID = ex.USER_ID
        and ex.status = 'active');

-- handling pending transcation and mapping the customer number if active in profile.
INSERT /*+ APPEND */ INTO  ${etlvar::TMPDB}.B_BIRMO_USER_REG_DTL_002
(
     USER_ID
     ,SUBR_NUM
     ,CUST_NUM
     ,REG_TYPE
     ,STATUS
     ,BILL_CYCLE
     ,REFERRER_USER_ID
     ,REFERRER_SUBR_NUM
     ,REFERRER_CUST_NUM
     ,CREATE_DATE
     ,CREATE_TIME
     ,SERVICE_PENDING_START_DATE
     ,SERVICE_PENDING_START_TIME
     ,CHL
     ,REFERRER_CD
     ,ECR
     ,ORDER_NUM
         ,RATE_PLAN_CD
     ,DAY_OF_BIRTH
     ,CONTACT_NUM
     ,OPER_CONTACT_NUM
     ,OPER_PORTIN
     ,TITLE
     ,ONLINE_STORE_FLG
     ,D_OPER_CONTACT_NUM
     ,D_OPER_PORTIN
     ,D_RATE_PLAN_CD_PTIN
     ,D_RATE_PLAN_GRP_PTIN
     ,D_FREE_DATA_ENTITLE_PTIN
     ,D_REVENUE_FLG_PTIN
     ,D_SUBR_SW_ON_DATE_PTIN
     ,D_SUBR_SW_OFF_DATE_PTIN
     ,D_TENURE_PTIN
     ,D_RATE_PLAN_CD_CNUM
     ,D_RATE_PLAN_GRP_CNUM
     ,D_FREE_DATA_ENTITLE_CNUM
     ,D_REVENUE_FLG_CNUM
     ,D_SUBR_SW_ON_DATE_CNUM
     ,D_SUBR_SW_OFF_DATE_CNUM
     ,D_TENURE_CNUM
         ,EMAIL_ADDR
     ,DELIVERY_PREFERENCE
     ,FIRST_PAYMENT_TOOL_REG
  ,AUTOPAY_INDICATOR
    ,PORT_IN_OPER_CUST_SELECTED
    ,BOLT_ON_BILL_CODE
)
WITH ACTIVE_SUB AS (
        SELECT   /*+MATERIALIZE */  a.cust_num,a.subr_num,a.start_date,a.end_date
       FROM ${etlvar::ADWDB}.SUBR_INFO_HIST a, ${etlvar::ADWDB}.RATE_PLAN_REF b
       where a.subr_stat_cd = 'OK'
       and a.rate_plan_cd = b.rate_plan_cd
       AND b.netw=16)
SELECT DISTINCT
     a.USER_ID
     ,a.SUBR_NUM
     ,COALESCE(b.CUST_NUM,a.cust_num)
     ,a.REG_TYPE
     ,a.STATUS
     ,a.BILL_CYCLE
     ,a.REFERRER_USER_ID
     ,a.REFERRER_SUBR_NUM
     ,a.REFERRER_CUST_NUM
     ,a.CREATE_DATE
     ,a.CREATE_TIME
     ,a.SERVICE_PENDING_START_DATE
     ,a.SERVICE_PENDING_START_TIME
     ,a.CHL
     ,a.REFERRER_CD
     ,a.ECR
     ,a.ORDER_NUM
     ,a.RATE_PLAN_CD
     ,a.DAY_OF_BIRTH
     ,a.CONTACT_NUM
     ,a.OPER_CONTACT_NUM
     ,a.OPER_PORTIN
     ,a.TITLE
     ,a.ONLINE_STORE_FLG
     ,a.D_OPER_CONTACT_NUM
     ,a.D_OPER_PORTIN
     ,a.D_RATE_PLAN_CD_PTIN
     ,a.D_RATE_PLAN_GRP_PTIN
     ,a.D_FREE_DATA_ENTITLE_PTIN
     ,a.D_REVENUE_FLG_PTIN
     ,a.D_SUBR_SW_ON_DATE_PTIN
     ,a.D_SUBR_SW_OFF_DATE_PTIN
     ,a.D_TENURE_PTIN
     ,a.D_RATE_PLAN_CD_CNUM
     ,a.D_RATE_PLAN_GRP_CNUM
     ,a.D_FREE_DATA_ENTITLE_CNUM
     ,a.D_REVENUE_FLG_CNUM
     ,a.D_SUBR_SW_ON_DATE_CNUM
     ,a.D_SUBR_SW_OFF_DATE_CNUM
     ,a.D_TENURE_CNUM
         ,a.EMAIL_ADDR
     ,a.DELIVERY_PREFERENCE
     ,a.FIRST_PAYMENT_TOOL_REG
  ,a.AUTOPAY_INDICATOR
    ,a.PORT_IN_OPER_CUST_SELECTED
        ,a.BOLT_ON_BILL_CODE
FROM ${etlvar::TMPDB}.B_BIRMO_USER_REG_DTL_001 a
LEFT OUTER JOIN ACTIVE_SUB b
ON a.subr_num = b.subr_num
AND a.CREATE_DATE between b.start_date and b.end_date
WHERE a.status = 'pending';

INSERT /*+ APPEND */ INTO  ${etlvar::TMPDB}.B_BIRMO_USER_REG_DTL_002
(
     USER_ID
     ,SUBR_NUM
     ,CUST_NUM
     ,REG_TYPE
     ,STATUS
     ,BILL_CYCLE
     ,REFERRER_USER_ID
     ,REFERRER_SUBR_NUM
     ,REFERRER_CUST_NUM
     ,CREATE_DATE
     ,CREATE_TIME
     ,SERVICE_PENDING_START_DATE
     ,SERVICE_PENDING_START_TIME
     ,CHL
     ,REFERRER_CD
     ,ECR
     ,ORDER_NUM
         ,RATE_PLAN_CD
     ,DAY_OF_BIRTH
     ,CONTACT_NUM
     ,OPER_CONTACT_NUM
     ,OPER_PORTIN
     ,TITLE
     ,ONLINE_STORE_FLG
     ,D_OPER_CONTACT_NUM
     ,D_OPER_PORTIN
     ,D_RATE_PLAN_CD_PTIN
     ,D_RATE_PLAN_GRP_PTIN
     ,D_FREE_DATA_ENTITLE_PTIN
     ,D_REVENUE_FLG_PTIN
     ,D_SUBR_SW_ON_DATE_PTIN
     ,D_SUBR_SW_OFF_DATE_PTIN
     ,D_TENURE_PTIN
     ,D_RATE_PLAN_CD_CNUM
     ,D_RATE_PLAN_GRP_CNUM
     ,D_FREE_DATA_ENTITLE_CNUM
     ,D_REVENUE_FLG_CNUM
     ,D_SUBR_SW_ON_DATE_CNUM
     ,D_SUBR_SW_OFF_DATE_CNUM
     ,D_TENURE_CNUM
         ,EMAIL_ADDR
     ,DELIVERY_PREFERENCE
     ,FIRST_PAYMENT_TOOL_REG
  ,AUTOPAY_INDICATOR
    ,PORT_IN_OPER_CUST_SELECTED
    ,BOLT_ON_BILL_CODE
)
SELECT DISTINCT USER_ID
     ,SUBR_NUM
     ,CUST_NUM
     ,REG_TYPE
     ,STATUS
     ,BILL_CYCLE
     ,REFERRER_USER_ID
     ,REFERRER_SUBR_NUM
     ,REFERRER_CUST_NUM
     ,CREATE_DATE
     ,CREATE_TIME
     ,SERVICE_PENDING_START_DATE
     ,SERVICE_PENDING_START_TIME
     ,CHL
     ,REFERRER_CD
     ,ECR
     ,ORDER_NUM
         ,RATE_PLAN_CD
     ,DAY_OF_BIRTH
     ,CONTACT_NUM
     ,OPER_CONTACT_NUM
     ,OPER_PORTIN
     ,TITLE
     ,ONLINE_STORE_FLG
     ,D_OPER_CONTACT_NUM
     ,D_OPER_PORTIN
     ,D_RATE_PLAN_CD_PTIN
     ,D_RATE_PLAN_GRP_PTIN
     ,D_FREE_DATA_ENTITLE_PTIN
     ,D_REVENUE_FLG_PTIN
     ,D_SUBR_SW_ON_DATE_PTIN
     ,D_SUBR_SW_OFF_DATE_PTIN
     ,D_TENURE_PTIN
     ,D_RATE_PLAN_CD_CNUM
     ,D_RATE_PLAN_GRP_CNUM
     ,D_FREE_DATA_ENTITLE_CNUM
     ,D_REVENUE_FLG_CNUM
     ,D_SUBR_SW_ON_DATE_CNUM
     ,D_SUBR_SW_OFF_DATE_CNUM
     ,D_TENURE_CNUM
         ,EMAIL_ADDR
     ,DELIVERY_PREFERENCE
     ,FIRST_PAYMENT_TOOL_REG
  ,AUTOPAY_INDICATOR
    ,PORT_IN_OPER_CUST_SELECTED
    ,BOLT_ON_BILL_CODE
FROM ${etlvar::TMPDB}.B_BIRMO_USER_REG_DTL_001 a
WHERE NOT EXISTS (
SELECT 'X'
FROM ${etlvar::TMPDB}.B_BIRMO_USER_REG_DTL_002 b
WHERE a.USER_ID = b.USER_ID)
AND NOT EXISTS (
        SELECT 'X'
        FROM ${etlvar::ADWDB}.BIRMO_USER_REG_DTL ex
        where a.USER_ID = ex.USER_ID);

INSERT /*+ APPEND */ INTO  ${etlvar::TMPDB}.B_BIRMO_USER_REG_DTL_002
(
     USER_ID
     ,SUBR_NUM
     ,CUST_NUM
     ,REG_TYPE
     ,STATUS
     ,BILL_CYCLE
     ,REFERRER_USER_ID
     ,REFERRER_SUBR_NUM
     ,REFERRER_CUST_NUM
     ,CREATE_DATE
     ,CREATE_TIME
     ,SERVICE_PENDING_START_DATE
     ,SERVICE_PENDING_START_TIME
     ,CHL
     ,REFERRER_CD
     ,ECR
     ,ORDER_NUM
         ,RATE_PLAN_CD
     ,DAY_OF_BIRTH
     ,CONTACT_NUM
     ,OPER_CONTACT_NUM
     ,OPER_PORTIN
     ,TITLE
     ,ONLINE_STORE_FLG
     ,D_OPER_CONTACT_NUM
     ,D_OPER_PORTIN
     ,D_RATE_PLAN_CD_PTIN
     ,D_RATE_PLAN_GRP_PTIN
     ,D_FREE_DATA_ENTITLE_PTIN
     ,D_REVENUE_FLG_PTIN
     ,D_SUBR_SW_ON_DATE_PTIN
     ,D_SUBR_SW_OFF_DATE_PTIN
     ,D_TENURE_PTIN
     ,D_RATE_PLAN_CD_CNUM
     ,D_RATE_PLAN_GRP_CNUM
     ,D_FREE_DATA_ENTITLE_CNUM
     ,D_REVENUE_FLG_CNUM
     ,D_SUBR_SW_ON_DATE_CNUM
     ,D_SUBR_SW_OFF_DATE_CNUM
     ,D_TENURE_CNUM
         ,EMAIL_ADDR
     ,DELIVERY_PREFERENCE
     ,FIRST_PAYMENT_TOOL_REG
  ,AUTOPAY_INDICATOR
    ,PORT_IN_OPER_CUST_SELECTED
    ,BOLT_ON_BILL_CODE
)
SELECT DISTINCT a.USER_ID
     ,a.SUBR_NUM
     ,b.CUST_NUM
     ,a.REG_TYPE
     ,'active'
     ,a.BILL_CYCLE
     ,a.REFERRER_USER_ID
     ,a.REFERRER_SUBR_NUM
     ,a.REFERRER_CUST_NUM
     ,a.CREATE_DATE
     ,a.CREATE_TIME
     ,a.SERVICE_PENDING_START_DATE
     ,a.SERVICE_PENDING_START_TIME
     ,a.CHL
     ,a.REFERRER_CD
     ,a.ECR
     ,a.ORDER_NUM
         ,a.RATE_PLAN_CD
     ,a.DAY_OF_BIRTH
     ,a.CONTACT_NUM
     ,a.OPER_CONTACT_NUM
     ,a.OPER_PORTIN
     ,a.TITLE
     ,a.ONLINE_STORE_FLG
     ,a.D_OPER_CONTACT_NUM
     ,a.D_OPER_PORTIN
     ,a.D_RATE_PLAN_CD_PTIN
     ,a.D_RATE_PLAN_GRP_PTIN
     ,a.D_FREE_DATA_ENTITLE_PTIN
     ,a.D_REVENUE_FLG_PTIN
     ,a.D_SUBR_SW_ON_DATE_PTIN
     ,a.D_SUBR_SW_OFF_DATE_PTIN
     ,a.D_TENURE_PTIN
     ,a.D_RATE_PLAN_CD_CNUM
     ,a.D_RATE_PLAN_GRP_CNUM
     ,a.D_FREE_DATA_ENTITLE_CNUM
     ,a.D_REVENUE_FLG_CNUM
     ,a.D_SUBR_SW_ON_DATE_CNUM
     ,a.D_SUBR_SW_OFF_DATE_CNUM
     ,a.D_TENURE_CNUM
         ,a.EMAIL_ADDR
     ,a.DELIVERY_PREFERENCE
     ,a.FIRST_PAYMENT_TOOL_REG
  ,a.AUTOPAY_INDICATOR
    ,a.PORT_IN_OPER_CUST_SELECTED
    ,a.BOLT_ON_BILL_CODE
FROM ${etlvar::ADWDB}.BIRMO_USER_REG_DTL a,${etlvar::ADWDB}.SUBR_INFO_HIST b,${etlvar::ADWDB}.RATE_PLAN_REF c
where a.subr_num = b.subr_num
and TO_DATE('${etlvar::TXDATE}','YYYY-MM-DD')-1 BETWEEN b.start_date AND b.end_date
and b.subr_stat_cd = 'OK'
and b.rate_plan_Cd = c.rate_plan_cd
and c.netw = 16
and a.status <> 'active'
AND NOT EXISTS (
        SELECT 'X'
        FROM ${etlvar::ADWDB}.BIRMO_USER_REG_DTL ex
        where a.USER_ID = ex.USER_ID
        and EX.STATUS = 'active')
AND NOT EXISTS (
        SELECT 'X'
        FROM ${etlvar::TMPDB}.B_BIRMO_USER_REG_DTL_002 ex2
        where a.USER_ID = ex2.USER_ID
        and EX2.STATUS = 'active');

update ${etlvar::TMPDB}.B_BIRMO_USER_REG_DTL_002
set service_pending_start_date = TO_DATE('${etlvar::MINDATE}','YYYY-MM-DD'),service_pending_start_time = 0
where service_pending_start_date = date'2200-01-01';

update ${etlvar::TMPDB}.B_BIRMO_USER_REG_DTL_002
set REFERRER_USER_ID='1320',REFERRER_SUBR_NUM='91311675',REFERRER_CUST_NUM='11230534'
where subr_num in (
SELECT distinct subr_num
FROM ${etlvar::ADWDB}.SUBR_INFO_HIST
where imsi in (select dw_imsi from ${etlvar::ADWDB}.BIRMO_PATCH_DS))
and referrer_user_id = ' ';

COMMIT;



ENDOFINPUT

    close(SQLPLUS);
    my $RET_CODE = $? >> 8;
    if ($RET_CODE != 0){
        return 1;
    }else{
        return 0;
    }
}







#We need to have variable input for the program to start
if ($#ARGV < 0){
    print("Syntax : perl <Script Name> <System Name>_<Job Name>_<TXDATE>.dir>\n");
    print("Example: perl b_cust_info0010.pl adw_b_cust_info_20051010.dir\n");
    exit(1);
}




#Call the function we want to run
open(STDERR, ">&STDOUT");

my $pre = etlvar::preProcess($ARGV[0]);
my $rc = etlvar::getTXDate($MASTER_TABLE);


my $ret = runSQLPLUS();


my $post = etlvar::postProcess();

exit($ret);











