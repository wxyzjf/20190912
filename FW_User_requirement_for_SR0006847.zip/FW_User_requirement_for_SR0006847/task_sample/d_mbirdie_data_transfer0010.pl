/opt/etl/prd/etl/APP/USR/D_MBIRDIE_DATA_TRANSFER/bin> cat d_mbirdie_data_transfer0010.pl
######################################################
#   $Header: /CVSROOT/SmarTone-Vodafone/Code/ETL/APP/ORM/D_ACTIVATION_LIST/bin/d_activation_list0010.pl,v 1.1 2005/12/14 01:04:39 MichaelNg Exp $
#   Purpose:
#   
#
######################################################


my $ETLVAR = $ENV{"AUTO_ETLVAR"};require $ETLVAR;


#We need to have variable input for the program to start
if ($#ARGV < 0){
    print("Syntax : perl <Script Name> <System Name>_<Job Name>_<TXDATE>.dir>\n");
    print("Example: perl d_cust_info001.pl adw_d_cust_info_20051010.dir\n");
    exit(1);
}


my $MASTER_TABLE = ""; #Please input the final target ADW table name here
my $LOADING_TABLE_DB = "$etlvar::TMPDB"; #Please use the variable name defined in the etlvar
$etlvar::DS_MLOAD = "N";  # Y - indicate a multiload job and N - indicate a fastload job


#Call the function we want to run
open(STDERR, ">&STDOUT");

my $pre = etlvar::preProcess($ARGV[0]);
my $ret = etlvar::runDataStageJob($LOADING_TABLE_DB, $MASTER_TABLE);
my $post = etlvar::postProcess($MASTER_TABLE);
 
 
exit($ret);
