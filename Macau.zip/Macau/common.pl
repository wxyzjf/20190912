/home/modwbat/modw/script> cat common.pl
#
# $Header: /mountfs1/cr1/dw/script/RCS/common.pl,v 1.5 2000/10/04 02:16:01 cr1 Exp $
# 
# $Locker:  $
# 
# $Log: common.pl,v $
#Revision 1.5  2000/10/04  02:16:01  cr1
#select line or bar in gengraph
#
#Revision 1.4  2000/10/04  01:48:29  cr1
#Unknown
#
#Revision 1.3  2000/02/11  04:37:46  cr1
#beautify the code
#
#Revision 1.2  2000/02/11  04:33:24  cr1
#handle precision = 0 case for commas function
#
#Revision 1.1  2000/02/11  04:26:39  cr1
#Common function for the Perl Program
#
# 

$tbcolor = '#000066';
$fpcolor = '#0000a0';
$fncolor = 'red';
$b1color = '#ccffff';
$b2color = '#99ccff';
$b3color = '#6699ff';
$b4color = '#0066cc';
$b5color = '#0000ff';

#
# Commas Function
#
sub commas {
#
# $decimal is the printed number
# $precise is the number of precision
# 
  local($decimal, $precision) = @_;
#
# if no precision is specified, use the default value
# 
  $precision = -1 if ! defined $precision;
#
# Split the integer and the decimal part
# 
  @num = split /\./, $decimal;
#
# Place the commas for the integer part
#
  1 while $num[0] =~ s/(.*\d)(\d\d\d)/$1,$2/;
#
# Place the trailing zero for the specified precision
# 
  if ($precision > 0) {
    $num[1] = 0 if scalar @num == 1;
    $num[1] = substr($num[1], 0, $precision);
    $num[1] .= 0 x ($precision - length($num[1]));
  }
#
# Format the printed number
# 
  $retnum = $num[0];
  $retnum .= "." . $num[1] if scalar @num > 1 && $precision != 0; 

  return $retnum;
}
#
# Generate 3D SAS Graph Code
# 
sub gengraph {
  local($charttype, *xvalue, $xlabel, $xtype, 
        *yvalue, $ylabel, $ytype,
        $filename, $width, $height,
        $drilldown, $drillpatfirst, $drillpatlast,
        $drillsite, $drilltarget) = @_;

  shift @_ if $charttype eq "LINE" || $charttype eq "BAR";
  (*xvalue, $xlabel, $xtype, 
   *yvalue, $ylabel, $ytype,
   $filename, $width, $height,
   $drilldown, $drillpatfirst, $drillpatlast,
   $drillsite, $drilltarget) = @_;

  $shape = "Block";
  if ($charttype ne "LINE") { 
    $charttype = 'BAR';
  }
  else {
    $shape = "Sphere";
  }
#
# xvalue - Array of x value
# xlabel - X-axis label 
# xtype  - Type of x value(Numeric, Text, Dollar)
# yvalue - Array of y value
# ylabel - Y-axis label
# ytype  - Type of y value(Numeric, Text, Dollar)
# filename - File Name to print
# width  - Width of the 3D Graph
# height - Height of the 3D Graph
# drilldown - wether the graph is drillable
# drillpatfirst - the prefix of the drill down pattern
# drillpatlast - the suffix of the drill down pattern
# drillsite - WEB site of the drill down pattern
# drilltarget - WEB site of the drill down target
# 
  
#
# Validate options and set default value
# 
  $drilldown = "N" if (! defined($drilldown));  
  $drillsite = "/" if (! defined($drillsite));
  $drilltarget = "_self" if (! defined($drilltarget));
  $drilldown =~ y/a-z/A-Z/;

  open(HTMLFILE, ">>$filename") or die "\nCannot append to $filename\n";

  die "\nInvalid Drill Down Option" if (! ($drilldown =~ /[YN]/));

  if ($drilldown eq "N") {
    $drilloption = '<PARAM NAME="DISABLEDRILLDOWN" VALUE="Y">';
  }
  else {
    $drilloption = '<PARAM NAME="DRILLDOWNMODE" VALUE="ANY">' . "\n  " .
                   '<PARAM NAME="DRILLPATTERN" VALUE="' . $drillsite . 
                   $drillpatfirst . '{&g_indepv,f}' . $drillpatlast . '">';
  }

  die "\n$xtype is invalid X Type\n" 
    if ($xtype ne "Numeric" && $xtype ne "Text" && $xtype ne "Dollar");

  die "\n$ytype is invalid Y type\n" 
    if ($ytype ne "Numeric" && $ytype ne "Text" && $ytype ne "Dollar"); 

  $extraxparm = "\n";
  $extrayparm = "\n";

  $extraxparm = '<PARAM NAME="G_INDEPF" VALUE="COMMA18.">' 
    if $xtype eq "Numeric";
  $extrayparm = '<PARAM NAME="G_DEPF" VALUE="COMMA18.">' 
    if $ytype eq "Numeric";

  if ($xtype eq "Dollar") {
    $extraxparm = '<PARAM NAME="G_INDEPF" VALUE="DOLLAR18.">';
    $xtype = "Numeric";
  }

  if ($ytype eq "Dollar") {
    $extrayparm = '<PARAM NAME="G_DEPF" VALUE="DOLLAR18.">';
    $ytype = "Numeric";
  }
  print HTMLFILE<<EOHTML;
<SCRIPT LANGUAGE="JavaScript">
  function saveit(applet) {
    document.cookie = applet.GetState() ;
  }
 
  function restoreit(applet) {
    var mycookie = applet.ExtractCookie( document.cookie ) ; 
    if (mycookie != "")
      applet.SetState(mycookie);
  }
</SCRIPT>
 
<center>
 
<APPLET CODE="GraphApplet.class" NAME="Graph" 
        ARCHIVE="/mosas/sasweb/graph/GraphApp.jar"
        ALT="SmarTone Mobile Communications Limited" 
        WIDTH="$width" HEIGHT="$height" MAYSCRIPT>
  <PARAM NAME="GRAPHTYPE" VALUE="$charttype">
  <PARAM NAME="SHAPE" VALUE="$shape">
  <PARAM NAME="SHOWLEGEND" VALUE="Y">
  <PARAM NAME="G_INDEPT" VALUE="$xtype">
  <PARAM NAME="G_INDEP" VALUE="$xlabel">
  $extraxparm
  <PARAM NAME="G_DEPT" VALUE="$ytype">
  <PARAM NAME="G_DEP" VALUE="$ylabel">
  $extrayparm 
EOHTML

  $index = 0;
  while (defined($xvalue[$index])) {
    print HTMLFILE '  <PARAM NAME="G_INDEPV', $index + 1, '" VALUE="', 
                   $xvalue[$index], '">', "\n"; 
    print HTMLFILE '  <PARAM NAME="G_DEPV', $index + 1, '" VALUE="', 
                   $yvalue[$index], '">', "\n"; 
    $index++
  }

  print HTMLFILE<<EOHTML;
  <PARAM NAME="SHOWGRID" VALUE="Y">
  <PARAM NAME="DRILLTARGET" VALUE="$drilltarget">
  $drilloption 
  <PARAM NAME="STATEREDRAW" VALUE="Y">
  <PARAM NAME="SAVEFUNC" VALUE="saveit">
  <PARAM NAME="RESTOREFUNC" VALUE="restoreit">
  <PARAM NAME="EXTERNALNAME" VALUE="_Graph999A5kn6LS">
</APPLET>
</center>
EOHTML
  close(HTMLFILE);
}  
return 1;

sub octstr{
  my($hexval) = @_;
  return hex($hexval);
}

