/home/modwbat/modw/sql> cat dw_load_gprs_002.sql
---map status OK first. other map the first record
UPDATE TMP_GPRS_CALL_RECS A
SET (CUST_NUM,RATE_PLAN_CD ) = (
      SELECT CUST_NUM,RATE_PLAN_CD
      FROM SUBR_INFO
      WHERE SUBR_NUM = A.SUBR_NUM
      AND   SUBR_SW_ON_DATE <= A.CALL_START_DATE
      AND   NVL(SUBR_SW_OFF_DATE, to_date('2999-12-31','yyyy-mm-dd')) >= A.CALL_START_DATE
      AND   SUBR_STATUS = 'OK'
    ),
    REFRESH_TS = sysdate
WHERE   CUST_NUM is null 
;
commit;

UPDATE TMP_GPRS_CALL_RECS A
SET (CUST_NUM,RATE_PLAN_CD) = (
      SELECT CUST_NUM,RATE_PLAN_CD
      FROM SUBR_INFO
      WHERE SUBR_NUM = A.SUBR_NUM
      AND   SUBR_SW_ON_DATE <= A.CALL_START_DATE
      AND   NVL(SUBR_SW_OFF_DATE, to_date('2999-12-31','yyyy-mm-dd')) >= A.CALL_START_DATE
      AND   SUBR_STATUS != 'OK'
      AND   ROWNUM = 1
    ),
    REFRESH_TS = sysdate
WHERE   CUST_NUM is null 
;
commit;

UPDATE TMP_GPRS_CALL_RECS B
SET (CUST_NUM,RATE_PLAN_CD ) = (
      SELECT CUST_NUM, CARD_TYPE_CD
      FROM PPD_CARD_HIST
      WHERE SUBR_NUM = B.SUBR_NUM
      AND   CARD_DATE = B.CALL_START_DATE
      AND   CARD_STATUS_CD = 'A'
    ),
    REFRESH_TS = sysdate
WHERE B.CUST_NUM IS NULL
;
commit;



UPDATE TMP_GPRS_CALL_RECS B
SET (CUST_NUM,RATE_PLAN_CD) = (
      SELECT CUST_NUM, CARD_TYPE_CD
      FROM PPD_CARD_HIST
      WHERE SUBR_NUM = B.SUBR_NUM
      AND   CARD_DATE = B.CALL_START_DATE
      AND   CARD_STATUS_CD <> 'A'
      AND  CARD_STATUS_CD <> 'TX' --Added by Bill 29/07/2010 
      AND  expd_date = (select max(expd_date)from ppd_card_hist c where c.card_date =B.CALL_START_DATE and c.subr_num =b.subr_num)
    ),
    REFRESH_TS = sysdate
WHERE B.CUST_NUM IS NULL
;


commit;




quit;
