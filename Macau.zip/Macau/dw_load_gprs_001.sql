/home/modwbat/modw/sql> cat dw_load_gprs_001.sql
exec sp_trunctbl('TMP_GPRS_CALL_RECS');
exec sp_trunctbl('TMP_GPRS_CALL_RECS_02');
commit;
quit;
