/home/modwbat/modw/sql> cat dw_load_gprs_002-2.sql
exec sp_trunctbl('TMP_GPRS_CALL_RECS_02');

insert /*+ append */ into TMP_GPRS_CALL_RECS_02
(
  CUST_NUM          ,
  SUBR_NUM          ,
  CALL_START_DATE   ,
  CALL_START_TIME   ,
  REC_SEQ           ,
  IMSI              ,
  DIALED_DIGITS     ,
  SGSN_IP           ,
  GGSN_IP           ,
  CHARGING_ID       ,
  CAUSE_ID          ,
  NODE_ID           ,
  FTM_ID            ,
  MS_NET_CAP        ,
  ROUTING_AREA      ,
  CALL_REC_TYPE_CD  ,
  LOCTN_AREA_CD     ,
  CELL_SITE_CD      ,
  PDP_TYPE_CD       ,
  GPRS_SERV_ID      ,
  APN_NI            ,
  APN_OI            ,
  SERV_PDP_ADDR     ,
  QOS_R_RELY        ,
  QOS_R_DELAY       ,
  QOS_R_PERCENDENCE ,
  QOS_R_PK          ,
  QOS_R_MEAN        ,
  QOS_N_RELY        ,
  QOS_N_DELAY       ,
  QOS_N_PERCENDENCE ,
  QOS_N_PK          ,
  QOS_N_MEAN        ,
  CALL_END_CNDTN    ,
  CALL_END_DATE     ,
  CALL_END_TIME     ,
  SGSN_CHG          ,
  DYNAMIC_ADDR_FLG  ,
  OUTPUT_FLG        ,
  PLMN              ,
  CALL_DUR          ,
  MAP_ERR_VAL       ,
  DATA_UP_VOL       ,
  DATA_DOWN_VOL     ,
  SERV_UP_VOL       ,
  SERV_DOWN_VOL     ,
  BILL_END_DATE     ,
  RATE_PLAN_CD      ,
  BILL_CD           ,
  ORIG_SUBR_NUM     ,
  SGSN_IP_NEW       ,
  GGSN_IP_NEW       ,
  SGSN_PLMN         ,
  IMEI              ,
  RAW_DATA_UP_VOL   ,
  RAW_DATA_DOWN_VOL ,
  RAW_SERV_UP_VOL   ,
  RAW_SERV_DOWN_VOL ,
  CREATE_TS         ,
  REFRESH_TS        ,
  INSERT_DATE       ,
  FILE_NAME         ,
  RAT_TYPE          ,
  HS_MDL            
)
select 
  rec.CUST_NUM,
  rec.SUBR_NUM,
  rec.CALL_START_DATE,
  rec.CALL_START_TIME,
  rec.REC_SEQ,
  rec.IMSI,
  rec.DIALED_DIGITS,
  rec.SGSN_IP,
  rec.GGSN_IP,
  rec.CHARGING_ID,
  rec.CAUSE_ID,
  rec.NODE_ID,
  rec.FTM_ID,
  rec.MS_NET_CAP,
  rec.ROUTING_AREA,
  rec.CALL_REC_TYPE_CD,
  rec.LOCTN_AREA_CD,
  rec.CELL_SITE_CD,
  rec.PDP_TYPE_CD,
  rec.GPRS_SERV_ID,
  rec.APN_NI,
  rec.APN_OI,
  rec.SERV_PDP_ADDR,
  rec.QOS_R_RELY,
  rec.QOS_R_DELAY ,
  rec.QOS_R_PERCENDENCE,
  rec.QOS_R_PK,
  rec.QOS_R_MEAN,
  rec.QOS_N_RELY,
  rec.QOS_N_DELAY,
  rec.QOS_N_PERCENDENCE,
  rec.QOS_N_PK,
  rec.QOS_N_MEAN,
  rec.CALL_END_CNDTN,
  rec.CALL_END_DATE,
  rec.CALL_END_TIME,
  rec.SGSN_CHG,
  rec.DYNAMIC_ADDR_FLG,
  rec.OUTPUT_FLG,
  ref.PLMN,
  rec.CALL_DUR,
  rec.MAP_ERR_VAL,
  rec.DATA_UP_VOL,
  rec.DATA_DOWN_VOL,
  rec.SERV_UP_VOL ,
  rec.SERV_DOWN_VOL,
  rec.BILL_END_DATE,
  rec.RATE_PLAN_CD,
  rec.BILL_CD,
  rec.ORIG_SUBR_NUM,
  rec.SGSN_IP_NEW,
  rec.GGSN_IP_NEW,
  rec.SGSN_PLMN,
  rec.IMEI,
  rec.RAW_DATA_UP_VOL,
  rec.RAW_DATA_DOWN_VOL,
  rec.RAW_SERV_UP_VOL,
  rec.RAW_SERV_DOWN_VOL,
  rec.CREATE_TS,
  rec.REFRESH_TS,
  rec.INSERT_DATE,
  rec.FILE_NAME,
  rec.RAT_TYPE,
  rec.HS_MDL
from TMP_GPRS_CALL_RECS rec 
left outer join 
  PLMN_IP_RANGE_REF ref
on 
  rec.sgsn_ip between ref.sgsn_ip_start_n and ref.sgsn_ip_end_n
;
commit;


DECLARE
    v_imei_len integer;
    cursor cur_imei_len is select distinct length(imei) from HS order by length(imei) desc;
BEGIN
    open cur_imei_len;
    loop

        fetch cur_imei_len into v_imei_len;
        exit when cur_imei_len%notfound;

        update TMP_GPRS_CALL_RECS_02 t
        set hs_mdl = (select max(hs_mdl) from HS r where substr(t.imei,1,v_imei_len)=r.imei)
        where t.hs_mdl is null;

    end loop;

    commit;

    close cur_imei_len;

END;
/

quit;
