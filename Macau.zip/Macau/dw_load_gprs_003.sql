/home/modwbat/modw/sql> cat dw_load_gprs_003.sql
insert /*+ append */ into gprs_call_recs select * from TMP_GPRS_CALL_RECS_02;
commit;
quit;
