/home/modwbat/modw/script> cat dw_gprs_convert_ggsn.pl
#!/usr/bin/perl -w
#
# $Header$
#
# $Locker$
#
# $Log$
use DBI;

unshift(@INC, "/opt/modw/script");
require "common.pl";

## Get Filename ##
$xmlfile = $ARGV[0];

#----------------------------------------+
#Variable Initialization GGSN File Format|
#----------------------------------------+
#MD_RECORD_TYPE        
#MD_IMSI               
#MD_MSISDN             
#MD_SGSN_IP            
#MD_GGSN_IP            
#MD_CHARGING_ID        
#MD_MS_NET_CAP         
#MD_ROUTING_AREA       
#MD_LOCATION_AREA_CODE 
#MD_CELL_ID            
#MD_APN_NI             
#MD_APN_OI             
#MD_PDPTYPE            
#MD_SERVEDPDP_ADDRESS  
#MD_QOS_R_RELY         
#MD_QOS_R_DELAY        
#MD_QOS_R_PRECEDENCE   
#MD_QOS_R_PEAK         
#MD_QOS_R_MEAN         
#MD_QOS_N_RELY         
#MD_QOS_N_DELAY        
#MD_QOS_N_PRECEDENCE   
#MD_QOS_N_PEAK         
#MD_QOS_N_MEAN         
#MD_DATAVOLUME_UP      
#MD_DATAVOLUME_DOWN    
#MD_CHANGECONDITION    
#MD_CHANGETIME         
#MD_RECORDOPENINGTIME  
#MD_DURATION           
#MD_SGSNCHANGE         
#MD_CAUSE_REC_CLOSING  
#MD_0408_CAUSE         
#MD_0902_MAP_ERR       
#MD_REC_SEQ_NUM        
#MD_NODE_ID            
#MD_DYNAMIC_ADD_FLAG   
#MD_FTMID              
#MD_DIALLED_DIGITS     
#MD_SERVICE_NUMBER     
#MD_SERVICE_UP         
#MD_SERVICE_DOWN       
#MD_CHARGING_CHAR      
#MD_RAW_SERVICE_UP     
#MD_RAW_SERVICE_DOWN   
#MD_RAW_DATAVOLUME_UP  
#MD_RAW_DATAVOLUME_DOWN
#MD_IMEI               
#MD_RATTYPE            
#
#undef @url;
undef @value;
my ($MD_RECORD_TYPE,$MD_IMSI,$MD_MSISDN,$MD_SGSN_IP,$MD_GGSN_IP,$MD_CHARGING_ID,
 $MD_MS_NET_CAP ,$MD_ROUTING_AREA,$MD_LOCATION_AREA_CODE ,$MD_CELL_ID,$MD_APN_NI,
 $MD_APN_OI,$MD_PDPTYPE,$MD_SERVEDPDP_ADDRESS  ,$MD_QOS_R_RELY ,$MD_QOS_R_DELAY,
 $MD_QOS_R_PRECEDENCE,$MD_QOS_R_PEAK ,$MD_QOS_R_MEAN ,$MD_QOS_N_RELY ,$MD_QOS_N_DELAY,
 $MD_QOS_N_PRECEDENCE,$MD_QOS_N_PEAK ,$MD_QOS_N_MEAN ,$MD_DATAVOLUME_UP,$MD_DATAVOLUME_DOWN,
 $MD_CHANGECONDITION,$MD_CHANGETIME ,$MD_RECORDOPENINGTIME,$MD_DURATION,$MD_SGSNCHANGE,
 $MD_CAUSE_REC_CLOSING,$MD_0408_CAUSE,$MD_0902_MAP_ERR,$MD_REC_SEQ_NUM,$MD_NODE_ID,
 $MD_DYNAMIC_ADD_FLAG,$MD_FTMID,$MD_DIALLED_DIGITS,$MD_SERVICE_NUMBER,$MD_SERVICE_UP,
 $MD_SERVICE_DOWN,$MD_CHARGING_CHAR,$MD_RAW_SERVICE_UP,$MD_RAW_SERVICE_DOWN,$MD_RAW_DATAVOLUME_UP,
 $MD_RAW_DATAVOLUME_DOWN,$MD_IMEI,$MD_RATTYPE);


open(IN, $xmlfile) or die "Can't open file\n";

while ($Line = <IN> ){
        $MD_RECORD_TYPE        =substr($Line,0,2);
        $MD_IMSI               =substr($Line,2,15);
        $MD_MSISDN             =substr($Line,17,15);
        $MD_SGSN_IP            =substr($Line,32,30);
        $MD_GGSN_IP            =substr($Line,62,30);
        $MD_CHARGING_ID        =substr($Line,92,10);
        $MD_MS_NET_CAP         =substr($Line,102,10);
        $MD_ROUTING_AREA       =substr($Line,112,10);
        $MD_LOCATION_AREA_CODE =substr($Line,122,10);
        $MD_CELL_ID            =substr($Line,132,10);
        $MD_APN_NI             =substr($Line,142,30);
        $MD_APN_OI             =substr($Line,172,37);
        $MD_PDPTYPE            =substr($Line,209,10);
        $MD_SERVEDPDP_ADDRESS  =substr($Line,219,30);
        $MD_QOS_R_RELY         =substr($Line,249,10);
        $MD_QOS_R_DELAY        =substr($Line,259,10);
        $MD_QOS_R_PRECEDENCE   =substr($Line,269,10);
        $MD_QOS_R_PEAK         =substr($Line,279,10);
        $MD_QOS_R_MEAN         =substr($Line,289,10);
        $MD_QOS_N_RELY         =substr($Line,299,10);
        $MD_QOS_N_DELAY        =substr($Line,309,10);
        $MD_QOS_N_PRECEDENCE   =substr($Line,319,10);
        $MD_QOS_N_PEAK         =substr($Line,329,10);
        $MD_QOS_N_MEAN         =substr($Line,339,10);
        $MD_DATAVOLUME_UP      =substr($Line,349,15);
        $MD_DATAVOLUME_DOWN    =substr($Line,364,15);
        $MD_CHANGECONDITION    =substr($Line,379,10);
        $MD_CHANGETIME         =substr($Line,389,20);
        $MD_RECORDOPENINGTIME  =substr($Line,409,20);
        if (!($MD_RECORDOPENINGTIME =~ /^\d+/o)){
                next;
        }

        $MD_DURATION           =substr($Line,429,10);
        $MD_SGSNCHANGE         =substr($Line,439,10);
        $MD_CAUSE_REC_CLOSING  =substr($Line,449,10);
        $MD_0408_CAUSE         =substr($Line,459,10);
        $MD_0902_MAP_ERR       =substr($Line,469,10);
        $MD_REC_SEQ_NUM        =substr($Line,479,18);
        $MD_NODE_ID            =substr($Line,497,10);
        $MD_DYNAMIC_ADD_FLAG   =substr($Line,507,1);
        $MD_FTMID              =substr($Line,508,6);
        $MD_DIALLED_DIGITS     =substr($Line,514,18);
        $MD_SERVICE_NUMBER     =substr($Line,532,5);
        $MD_SERVICE_UP         =substr($Line,537,15);
        $MD_SERVICE_DOWN       =substr($Line,552,15);
        $MD_CHARGING_CHAR      =substr($Line,567,5);
        $MD_RAW_SERVICE_UP     =substr($Line,572,15);
        $MD_RAW_SERVICE_DOWN   =substr($Line,587,15);
        $MD_RAW_DATAVOLUME_UP  =substr($Line,602,15);
        $MD_RAW_DATAVOLUME_DOWN=substr($Line,617,15);
        $MD_IMEI               =substr($Line,632,16);
        $MD_RATTYPE            =substr($Line,648,2);
print $MD_RECORD_TYPE."|".$MD_IMSI."|".$MD_MSISDN."|".$MD_SGSN_IP."|".$MD_GGSN_IP."|".$MD_CHARGING_ID."|".  $MD_MS_NET_CAP ."|".$MD_ROUTING_AREA."|".$MD_LOCATION_AREA_CODE ."|".$MD_CELL_ID."|".$MD_APN_NI."|".  $MD_APN_OI."|".$MD_PDPTYPE."|".$MD_SERVEDPDP_ADDRESS  ."|".$MD_QOS_R_RELY ."|".$MD_QOS_R_DELAY."|".  $MD_QOS_R_PRECEDENCE."|".$MD_QOS_R_PEAK ."|".$MD_QOS_R_MEAN ."|".$MD_QOS_N_RELY ."|".$MD_QOS_N_DELAY."|".  $MD_QOS_N_PRECEDENCE."|".$MD_QOS_N_PEAK ."|".$MD_QOS_N_MEAN ."|".$MD_DATAVOLUME_UP."|".$MD_DATAVOLUME_DOWN."|".  $MD_CHANGECONDITION."|".$MD_CHANGETIME ."|".$MD_RECORDOPENINGTIME."|".$MD_DURATION."|".$MD_SGSNCHANGE."|".  $MD_CAUSE_REC_CLOSING."|".$MD_0408_CAUSE."|".$MD_0902_MAP_ERR."|".$MD_REC_SEQ_NUM."|".$MD_NODE_ID."|".  $MD_DYNAMIC_ADD_FLAG."|".$MD_FTMID."|".$MD_DIALLED_DIGITS."|".$MD_SERVICE_NUMBER."|".$MD_SERVICE_UP."|".  $MD_SERVICE_DOWN."|".$MD_CHARGING_CHAR."|".$MD_RAW_SERVICE_UP."|".$MD_RAW_SERVICE_DOWN."|".$MD_RAW_DATAVOLUME_UP."|".  $MD_RAW_DATAVOLUME_DOWN."|".$MD_IMEI."|".$MD_RATTYPE."|".$xmlfile."\n";
}
